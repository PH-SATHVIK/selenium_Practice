package Funtionality;

import java.io.FileInputStream;
import java.io.IOException;
import java.util.Properties;

import org.apache.poi.xssf.usermodel.XSSFRow;
import org.apache.poi.xssf.usermodel.XSSFSheet;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.edge.EdgeDriver;
import org.openqa.selenium.support.PageFactory;
import org.testng.annotations.Test;
import Objests.Elements;

import io.github.bonigarcia.wdm.WebDriverManager;

public class Registration {
	@Test
	public void f() throws IOException, InterruptedException {
		WebDriver driver;

		FileInputStream f2 = new FileInputStream("src//test//java/Config.properties");
		Properties prop = new Properties();
		prop.load(f2);

		String bname = prop.getProperty("browser");
		String epath = prop.getProperty("excelpath");
		String amazonURL = prop.getProperty("url");
		
		if (bname.equalsIgnoreCase("chrome")) {

			WebDriverManager.chromedriver();

			driver = new ChromeDriver();

		} else {
			WebDriverManager.edgedriver().setup();

			driver = new EdgeDriver();
		}

		FileInputStream fi = new FileInputStream(epath);
		XSSFWorkbook w1 = new XSSFWorkbook(fi);
		XSSFSheet s1 = w1.getSheetAt(0);

		for (int i = 1; i <= s1.getLastRowNum(); i++) {

			XSSFRow r1 = s1.getRow(i);

			String name = r1.getCell(0).getStringCellValue();
			String mobile = r1.getCell(1).getRawValue();
			String email = r1.getCell(2).getStringCellValue();
			String Pwd = r1.getCell(3).getRawValue();

			driver.navigate().to(amazonURL);

			driver.manage().window().maximize();

			PageFactory.initElements(driver, Elements.class);

			Elements.username.sendKeys(name);

			Elements.number.sendKeys(mobile);

			Elements.email.sendKeys(email);

			Elements.pwd.sendKeys(Pwd);

			Thread.sleep(2000);

			Elements.conti.click();

		}

	}
}
