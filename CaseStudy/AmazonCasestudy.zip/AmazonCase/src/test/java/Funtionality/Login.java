package Funtionality;

import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.edge.EdgeDriver;
import org.openqa.selenium.io.FileHandler;
import org.openqa.selenium.support.PageFactory;
import org.testng.annotations.Test;

import com.github.dockerjava.api.model.Driver;

import java.io.BufferedWriter;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileWriter;
import java.io.IOException;
import java.util.Iterator;
import java.util.Properties;
import java.util.Set;

import org.openqa.selenium.By;
import org.openqa.selenium.Cookie;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.OutputType;
import org.openqa.selenium.TakesScreenshot;
import org.openqa.selenium.WebDriver;

import Objests.Elements;
import io.github.bonigarcia.wdm.WebDriverManager;
import Funtionality.Registration;

public class Login {
	@Test
	public void f() throws IOException, InterruptedException {

		WebDriver driver;
		FileInputStream f2 = new FileInputStream("src//test//java/Config.properties");
		Properties prop = new Properties();
		prop.load(f2);

		String bname = prop.getProperty("browser");
		String Lurl = prop.getProperty("LoginURL");
		String mail1 = prop.getProperty("mail");
		String pawd = prop.getProperty("password");
		String ProductName = prop.getProperty("pname");

		if (bname.equalsIgnoreCase("chrome")) {

			WebDriverManager.chromedriver();

			driver = new ChromeDriver();

		} else {
			WebDriverManager.edgedriver().setup();

			driver = new EdgeDriver();
		}

		driver.navigate().to(Lurl);

		driver.manage().window().maximize();

		PageFactory.initElements(driver, Elements.class);

		Elements.Lmail.sendKeys(mail1);
		Elements.con1.click();

		Thread.sleep(1500);

		Elements.pass1.sendKeys(pawd);
		Elements.submit.click();

		Thread.sleep(1500);

		Elements.search.sendKeys(ProductName);

		Elements.gosearch.click();

		Elements.result.click();
		Thread.sleep(3000);

		Set<String> winHan = driver.getWindowHandles();

		Iterator<String> iter = winHan.iterator();

		String w1 = iter.next();

		String w2 = iter.next();

		driver.switchTo().window(w2);

		JavascriptExecutor js = (JavascriptExecutor) driver;

		js.executeScript("scroll(0,450)");

		Elements.atcbtn.click();

		Thread.sleep(4000);
		Elements.cancel.click();
		js.executeScript("scroll(0,-450)");
		Thread.sleep(1000);
		Elements.gotocart.click();

		TakesScreenshot ts = (TakesScreenshot) driver;

		File Source = ts.getScreenshotAs(OutputType.FILE);

		File dest = new File("src//test//java\\cart.png");

		FileHandler.copy(Source, dest);

	
	
	File CF=new File("src//test//java\\cookies.data");
	try {
		
		CF.createNewFile();
		FileWriter fw=new FileWriter(CF);
		BufferedWriter bw=new BufferedWriter(fw);
		
		for(Cookie ck:driver.manage().getCookies()) {
			
			bw.write((ck.getName()+";"+ck.getPath()+";"+ck.getDomain()+";"+ck.getValue()+";"+ck.getExpiry()+";"+ck.isSecure()));
			
			bw.newLine();
			
			
			driver.manage().deleteAllCookies();
			
			
		}
		
		bw.close();
		fw.close();
		
	}
	
	catch(Exception e) {
		
		System.out.println(e);
		
		
	}
	}}
			
		
		
		
		
	

