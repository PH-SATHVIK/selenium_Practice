package Objests;

import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;

public class Elements {
	
	@FindBy(id="ap_customer_name")
	
     public static WebElement	username;
	
	@FindBy(id="ap_phone_number")
	
	public static WebElement number;
	
	@FindBy(id="ap_email")
	
	public static WebElement email;
	
	@FindBy(id="ap_password")
	
	public static WebElement pwd;
	
	@FindBy(id="continue")
	
	public static WebElement conti;
	
	//Login Elements
	
	@FindBy(name="email")
	
	public static WebElement Lmail;
	
	@FindBy(xpath="//*[@id=\"continue\"]")
	
	public static WebElement con1;
	
	@FindBy(name="password")
	
	public static WebElement pass1;
	
	@FindBy(id="signInSubmit")
	
	public static WebElement submit;
	
	//Search elements
	
	@FindBy(id="twotabsearchtextbox")
	
	public static WebElement search;
	
	@FindBy(id="nav-search-submit-button")
	
	public static WebElement gosearch;
	
	@FindBy(xpath="//*[@id=\"search\"]/div[1]/div[1]/div/span[1]/div[1]/div[3]/div/div/div/div/div/div/div/div[2]/div/div/div[1]/h2/a/span")
	
	public static WebElement result;
	
	@FindBy(xpath="//*[@id=\"submit.add-to-cart\"]/span")
	
	public static WebElement atcbtn;
	
	@FindBy(xpath="//*[@id=\"attach-close_sideSheet-link\"]")
	
	public static WebElement cancel;
	
	@FindBy(id="nav-cart")
	public static WebElement gotocart;
	
	
	
	

}
